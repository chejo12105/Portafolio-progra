using System;
using System.Windows.Forms;

namespace T9_SACL_10
{
    public partial class Form1 : Form
    {
        private Motocicleta objMotocicleta;

        public Form1()
        {
            InitializeComponent();
            objMotocicleta = new Motocicleta(); 
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            
            int modelo = int.Parse(txtModelo.Text);
            string marca = txtMarca.Text;
            double precio = double.Parse(txtPrecio.Text);
            double iva = double.Parse(txtIva.Text);

            objMotocicleta.Modelo = modelo;
            objMotocicleta.Marca = marca;
            objMotocicleta.DefinirPrecio(precio);
            objMotocicleta.DefinirIva(iva);

            txtResultado.Text = objMotocicleta.MostrarDatos();
            txtPrecioSinIva.Text = objMotocicleta.PrecioSinIva.ToString("C");
            txtPrecioConIva.Text = objMotocicleta.PrecioConIva.ToString("C");
            txtMontoIva.Text = objMotocicleta.DevolverIva().ToString("C");
        }
    }
}
