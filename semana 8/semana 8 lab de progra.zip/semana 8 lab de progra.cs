﻿using System;

class Program
{
    static void Main()
    {
        int n, a, x;

        do
        {
            Console.Write("Ingrese un número entero mayor a 0 (n): ");
        } while (!int.TryParse(Console.ReadLine(), out n) || n <= 0);

 
        Console.Write("Ingrese un valor entero 'a': ");
        a = int.Parse(Console.ReadLine());

        Console.Write("Ingrese un valor entero 'x': ");
        x = int.Parse(Console.ReadLine());

     
        double sumaA = 0.0;
        for (int i = 1; i <= n; i++)
        {
            sumaA += 1.0 / i;
        }
        Console.WriteLine($"Serie a: {sumaA}");

        double sumaB = 0.0;
        for (int i = 1; i <= n; i++)
        {
            sumaB += 1.0 / Math.Pow(2, i);
        }
        Console.WriteLine($"Serie b: {sumaB}");

        double sumaC = 0.0;
        for (int k = 0; k <= n; k++)
        {
            sumaC += (Math.Pow(x, k) * Math.Pow(a, n - k)) / n;
        }
        Console.WriteLine($"Serie c: {sumaC}");
    }
}
