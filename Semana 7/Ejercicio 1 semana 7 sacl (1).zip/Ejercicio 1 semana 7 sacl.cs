﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1_semana_7_sacl
{
    internal class Program
    {
        static void Main(string[] args)
     
        {
            Console.WriteLine("Ejercicio 1");

            int numero;

            try
            {
                Console.Write("Número ENTERO: ");
                numero = int.Parse(Console.ReadLine());

                if (numero > 0)
                {
                    Console.WriteLine("RESULTADO: Positivo");
                }
                else if (numero < 0)
                {
                    Console.WriteLine("RESULTADO: Negativo");
                }
                else
                {
                    Console.WriteLine("RESULTADO: Cero");
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("ERROR: Ingrese un número entero válido.");
            }

            Console.ReadKey();
        }
    }

}
