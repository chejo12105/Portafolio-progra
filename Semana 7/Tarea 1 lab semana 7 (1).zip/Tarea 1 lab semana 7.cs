﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_1_lab_semana_7
{
    internal class Program
    {
        static void Main(string[] args)
    
        {
            List<double> cantidadesEnQuetzales = new List<double>();

            for (int i = 1; i <= 3; i++)
            {
                Console.Write($"Ingrese la cantidad No. {i}: ");
                double cantidad = double.Parse(Console.ReadLine());

                Console.Write("USD o GTQ: ");
                string moneda = Console.ReadLine().ToUpper();

                double cantidadEnQuetzales = 0;

                if (moneda == "USD")
                {
                    cantidadEnQuetzales = cantidad * 7.83;
                }
                else if (moneda == "GTQ")
                {
                    cantidadEnQuetzales = cantidad;
                }
                else
                {
                    Console.WriteLine("Moneda no válida. Use USD o GTQ.");
                    return;
                }

                cantidadesEnQuetzales.Add(cantidadEnQuetzales);
            }

            cantidadesEnQuetzales.Sort();

            Console.WriteLine("Resultado:");

            foreach (var cantidad in cantidadesEnQuetzales)
            {
                Console.WriteLine($"{cantidad:F2} GTQ");
            }

            Console.ReadKey();
        }
    }
}

