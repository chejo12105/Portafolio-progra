﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2_semana_7_sacl
{
    internal class Program
    {
        static void Main(string[] args)
      
        {
            Console.Write("Ingresa un número del 1 al 7: ");
            int numero = int.Parse(Console.ReadLine());

            string diaSemana = "";

            switch (numero)
            {
                case 1:
                    diaSemana = "lunes";
                    break;
                case 2:
                    diaSemana = "martes";
                    break;
                case 3:
                    diaSemana = "miércoles";
                    break;
                case 4:
                    diaSemana = "jueves";
                    break;
                case 5:
                    diaSemana = "viernes";
                    break;
                case 6:
                    diaSemana = "sábado";
                    break;
                case 7:
                    diaSemana = "domingo";
                    break;
                default:
                    Console.WriteLine("Número fuera del rango válido (1 al 7).");
                    break;
            }

            if (!string.IsNullOrEmpty(diaSemana))
            {
                Console.WriteLine($"El número {numero} corresponde a {diaSemana}.");
            }

            Console.ReadKey();
        }
    }

}
