﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5_SACL_1084123
{
    internal class Program
    {
        static void Main(string[] args)
    
        {
            Console.Write("Ingrese el monto de la compra: ");

            string entrada = Console.ReadLine();
            double monto;

            if (double.TryParse(entrada, out monto))
            {
                double descuento = 0.0;

                if (monto < 400)
                {
                   
                }
                else if (monto >= 400 && monto <= 1000)
                {
                    descuento = monto * 0.07;
                }
                else if (monto > 1000 && monto <= 5000)
                {
                    descuento = monto * 0.10;
                }
                else if (monto > 5000 && monto <= 15000)
                {
                    descuento = monto * 0.15;
                }
                else
                {
                    descuento = monto * 0.25;
                }

                Console.Write("¿Tiene un código de descuento? (Si/No): ");
                string tieneDescuento = Console.ReadLine();

                if (tieneDescuento.Equals("S", StringComparison.OrdinalIgnoreCase))
                {
                    descuento += monto * 0.05;
                }

                double montoFinal = monto - descuento;

                Console.WriteLine($"Monto al pagar final: {montoFinal:C}");
            }
            else
            {
                Console.WriteLine("Error: Ingrese un monto válido.");
            }

            Console.ReadKey();
        }
    }

}
