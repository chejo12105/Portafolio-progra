﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Semana_8_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");

            Console.Write("Nombre: ");
            string sNombre = Console.ReadLine();

            Console.Write("Edad: ");
            string sEdad = Console.ReadLine();

            Console.Write("Carrera: ");
            string sCarrera = Console.ReadLine();

            Console.Write("Carné: ");
            string sCarne = Console.ReadLine();

            Console.WriteLine("Mi segundo programa");
            Console.WriteLine("Nombre: " + sNombre);
            Console.WriteLine("Edad: " + sEdad);
            Console.WriteLine("Carrera: " + sCarrera);
            Console.WriteLine("Carné: " + sCarne);

            Console.WriteLine("Soy " + sNombre + ", tengo " + sEdad + " años y estudio la carrera de " + sCarrera + ".");
            Console.WriteLine("Mi número de carné es: " + sCarne);

            Console.ReadLine();
        }
    }
}
