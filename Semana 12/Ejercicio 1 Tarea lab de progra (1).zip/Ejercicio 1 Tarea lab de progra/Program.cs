﻿using System;

class Program
{
    static void Main()
    {
        // Solicitar al usuario los datos del triángulo
        Console.WriteLine("Por favor, ingrese los datos del triángulo rectángulo:");
        Console.Write("Longitud del cateto A (metros): ");
        double catetoA = Convert.ToDouble(Console.ReadLine());
        Console.Write("Ángulo opuesto al cateto A (grados): ");
        double anguloOpuestoA = Convert.ToDouble(Console.ReadLine());

        // Crear un objeto TrianguloRectangulo con los datos ingresados
        TrianguloRectangulo objTriangulo = new TrianguloRectangulo(catetoA, anguloOpuestoA);

        // Mostrar los resultados con formato adecuado
        Console.WriteLine("Datos del triángulo rectángulo:");
        Console.WriteLine("Cateto A: {0:F3} metros", objTriangulo.ObtenerCatetoA());
        Console.WriteLine("Cateto B: {0:F3} metros", objTriangulo.ObtenerCatetoB());
        Console.WriteLine("Hipotenusa: {0:F3} metros", objTriangulo.ObtenerHipotenusa());
        Console.WriteLine("Ángulo opuesto a A: {0:F3} grados", objTriangulo.ObtenerAnguloOpuestoA());
        Console.WriteLine("Ángulo opuesto a B: {0:F3} grados", objTriangulo.ObtenerAnguloOpuestoB());
        Console.WriteLine("Área: {0:F3} metros cuadrados", objTriangulo.ObtenerArea());
    }
}




