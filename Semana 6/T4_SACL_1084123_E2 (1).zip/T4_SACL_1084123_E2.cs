﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T4_SACL_1084123_E2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Muestra tu nombre y número de carné
            Console.WriteLine("Sergio Cifuentes 1084123");

            // Pide al usuario que ingrese una cantidad en quetzales
            Console.WriteLine("Ingrese un número:");
            string input = Console.ReadLine();

            // Intenta convertir la entrada del usuario en un valor decimal
            if (decimal.TryParse(input, out decimal cantidad))
            {
                // Calcula la equivalencia en billetes y monedas
                int billete100 = (int)(cantidad / 100);
                cantidad %= 100;
                int billete50 = (int)(cantidad / 50);
                cantidad %= 50;
                int billete20 = (int)(cantidad / 20);
                cantidad %= 20;
                int billete10 = (int)(cantidad / 10);
                cantidad %= 10;
                int billete5 = (int)(cantidad / 5);
                cantidad %= 5;
                int moneda1 = (int)cantidad;
                cantidad -= moneda1;
                int moneda25Centavos = (int)(cantidad / 0.25m);
                cantidad -= moneda25Centavos * 0.25m;
                int moneda1Centavo = (int)(cantidad / 0.01m);

                // Muestra los resultados
                Console.WriteLine($"{billete100} de Q 100");
                Console.WriteLine($"{billete50} de Q 50");
                Console.WriteLine($"{billete20} de Q 20");
                Console.WriteLine($"{billete10} de Q 10");
                Console.WriteLine($"{billete5} de Q 5");
                Console.WriteLine($"{moneda1} de Q 1");
                Console.WriteLine($"{moneda25Centavos} de 25 centavos");
                Console.WriteLine($"{moneda1Centavo} de 1 centavo");
            }
            else
            {
                Console.WriteLine("Entrada no válida. Debe ingresar un número válido.");
            }
        }
    }
}
